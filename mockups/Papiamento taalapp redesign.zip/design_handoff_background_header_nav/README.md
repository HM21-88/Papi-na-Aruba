# Handoff: Achtergrond, Header & Navigatie Redesign (Papiamento taalapp)

## Overview
Vervangt de vlakke bruine achtergrond van de webapp door een rijkere mesh-achtergrond, verplaatst de PAO/PAU-taaltoggle naar de rechterkant van de header op alle pagina's, verplaatst het filterknopje uit de header naar een contextuelere plek, en maakt de header sticky met een scroll-schaduw.

## About the design files
De bestanden in deze bundel zijn **HTML-designreferenties** (gemaakt als prototype), geen productiecode. De taak is om deze designs na te bouwen in de bestaande omgeving van de app (React, Vue, of wat er al gebruikt wordt) met de bestaande patronen/component-library — niet de HTML direct overnemen.

## Fidelity
**Hifi** — kleuren, typografie en states zijn definitief bedoeld; bouw pixel-nauwkeurig na met de bestaande component-library/design tokens van de app.

## Scope
Toepassen op: Home, Reis, Reis-detail (Hoofdstuk), Woordenlijst, Oefenen (overzicht), Voortgang, Profiel.
**Niet** toepassen op de game-/oefenschermen: Flashcards, Quiz, Trainers — die behouden hun huidige achtergrond en stijl.
Navigatie-iconen (Home/Reis/Oefenen/Voortgang/Profiel) blijven ongewijzigd — alleen hun container/positionering verandert.

## 1. Achtergrond (referentie: optie "4a" in Papiamento App Mockups.dc.html)
- Basis: effen crème `#f7efe1`.
- Drie vervaagde, verzadigde kleurvlekken (mesh gradient), elk `border-radius:50%`, `filter: blur(36–40px)`:
  - Teal `#0f5f56`, opacity .55, ~220×220px, rechtsboven (top:-50px; right:-40px)
  - Terracotta `#c8593a`, opacity .5, ~220×220px, linksmidden (top:120px; left:-70px)
  - Goud `#e0a72e`, opacity .55, ~200×200px, rechtsonder (bottom:-40px; right:20px)
- Fijne korrel-textuur eroverheen: SVG feTurbulence noise (fractalNoise, baseFrequency 0.85, numOctaves 2) als data-URI achtergrondlaag, `opacity:.3`, `background-blend-mode: overlay`/`mix-blend-mode: overlay`. Doel: subtiele "grip"/textuur, geen zichtbare korrels op afstand.
- Witte kaarten (`rgba(255,255,255,.95)` of `#fff`) blijven overal het primaire contentoppervlak — zij zorgen voor leesbaarheid tegen de kleurrijke achtergrond.
- De teal "Verder leren"-hero-kaart blijft teal (`#0f5f56`) — bewuste keuze voor visuele hiërarchie t.o.v. de achtergrond.

## 2. Header — taaltoggle naar rechts, sticky met scroll-schaduw
- Layout: `display:flex; justify-content:space-between; align-items:center; padding:14px 16px`.
- Links: paginatitel (Home) of terug-chevron + titel (subpagina's).
- **Rechts, altijd**: PAO/PAU-toggle — pill-vorm, wit `#fff` (of `rgba(255,255,255,.9)` op donkere achtergrond), actieve staat teal `#0f5f56` met witte tekst, inactieve staat grijsbruin `#9a8f80`.
- Header is **sticky** (blijft vast bovenaan tijdens scrollen van de content eronder).
- Header start **transparant/naadloos** met de achtergrond (`border-bottom: 1px solid transparent`, `box-shadow: none`).
- Zodra de content eronder scrolt (`scrollTop > 6px`), krijgt de header:
  - `border-bottom: 1px solid rgba(255,255,255,.3)` (pas de kleur aan indien header op lichte achtergrond staat)
  - `box-shadow: 0 4px 14px rgba(0,0,0,.18)`
  - transitie: `transition: box-shadow .2s, border-color .2s`
- Implementatie-hint: scroll-event op de scrollcontainer, state `isScrolled = scrollTop > 6`, conditioneel de border/shadow-classes togglen.

## 3. Bottom navigatie — vlak tegen de onderkant
- Navbar is een **normale flex-sibling** onderaan de pagina (niet floating, niet met marge los van de rand) — `background: rgba(255,255,255,.92)`, `box-shadow: 0 -2px 14px rgba(0,0,0,.15)`.
- 5 items gelijk verdeeld (`justify-content:space-around`), elk: icoon + label eronder, actieve state krijgt een lichte teal-tint achtergrond-pil (`#eaf2f0`) achter icoon+label en teal tekstkleur (`#0f5f56`).
- **Behoud de huidige iconen** (Home/Reis/Oefenen/Voortgang/Profiel) exact zoals ze nu zijn — alleen de container/achtergrond/actieve-staat-styling verandert.
- Zorg dat de content-scrollcontainer boven de navbar `flex:1; min-height:0` heeft zodat er nooit content onder de navbar terechtkomt (geen absolute overlay + padding-hack, gebruik een echte flex-layout: header → scrollbare content (flex:1) → navbar, alle drie flex-siblings in een flex-column pagina-container).

## 4. Filterknop — verplaatst uit de header
- **Woordenlijst**: filterknop verhuist van de header naar de zoekbalk-rij — als los knopje direct naast/aan het einde van het zoekveld (`display:flex; gap:8px` op de rij: zoekveld flex:1, filterknop vast 38×38px, rounded 12px).
- **Quiz**: filterknop verhuist naar de rij met statuschips (Goed/Fout/Herhaling) — als klein icoon-knopje aan het eind van die rij.
- Filterknop-icoon (sliders/3 lijnen met stipjes) blijft hetzelfde icoon, alleen de positie verandert.

## Design tokens
- Teal (primair): `#0f5f56`
- Terracotta (accent): `#c8593a`
- Goud (accent): `#e0a72e`
- Crème achtergrondbasis: `#f7efe1`
- Navy/donkere tekst: `#1e2f45`
- Bruine mutedtekst: `#6b6053` / `#8a7d6c`
- Kaart-achtergrond: `#ffffff` / `rgba(255,255,255,.95)`
- Border-radius kaarten: 14–18px; navbar-items: 12px; toggle: 999px (pill)
- Font: Nunito (400/600/700/800)

## Assets
Geen losse afbeeldingen — de korrel-textuur is een inline SVG (feTurbulence), geen extern bestand nodig. Iconen (navigatie, filter, zoeken, terug, speaker) zijn simpele inline SVG-lijniconen; vervang door de bestaande icon-set van de app waar die al bestaat (nav-iconen expliciet behouden, zie boven).

## Files in this bundle
- `Papiamento App Mockups.dc.html` — het volledige mockup-bestand met alle opties (1a–1c, 2a–2b, 3a, 4a). **Optie 4a is de gekozen eindrichting** voor achtergrond + navbar + sticky header; opties 1a/1b/1c tonen de toggle-rechts + filter-verplaatsing op Home en Woordenlijst.
